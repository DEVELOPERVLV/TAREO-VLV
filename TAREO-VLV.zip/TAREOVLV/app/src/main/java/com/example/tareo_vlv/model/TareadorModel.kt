package com.example.tareo_vlv.model

class TareadorModel(
    DNI: String?,
    SEDE: String?,
    CCOSTOS: String?
) {
    var DNI: String? = null;
    var SEDE: String? = null;
    var CCOSTOS: String? = null;

    init {
        this.DNI = DNI;
        this.SEDE = SEDE;
        this.CCOSTOS = CCOSTOS;
    }
}
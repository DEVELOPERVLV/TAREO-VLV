package com.example.tareo_vlv.actividades

class Delete {


}
package com.example.tareo_vlv.model

class CCenterModel(
        idcultivo: String,
        idconsumidor: String,

) {
    var idcultivo: String? = null
    var idconsumidor: String? = null


    init {
        this.idcultivo = idcultivo
        this.idconsumidor = idconsumidor
    }
}
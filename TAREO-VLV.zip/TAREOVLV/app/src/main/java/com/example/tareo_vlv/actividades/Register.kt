package com.example.tareo_vlv.actividades


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.tareo_vlv.Confirmation_Send
import com.example.tareo_vlv.R
import com.example.tareo_vlv.crud.TareoCRUD
import com.example.tareo_vlv.model.PreModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.json.JSONArray
import org.json.JSONException
import kotlin.collections.HashMap


class Register : AppCompatActivity() {

    private lateinit var cantidad: TextView
    private lateinit var crud: TareoCRUD

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        //ESTE CODIGO OMITE EL MODO OSCURO EN LA APLICACION
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //ESTE CODIGO MANTIENE LA PANTALLA ENCENDIDA MIENTRAS ESTE ABIERTA LA APLICACION
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_register)



        crud = TareoCRUD(this)
        initView()
        val btnSend = findViewById<Button>(R.id.btnSend)
                btnSend.setOnClickListener {
                    val data = crud.getAllPre()
                    val jsonArray =  JSONArray()
                    for(i in 0 until data.size ){
                        val jsonObjectTareo = JSONObject()
                        try {
                            jsonObjectTareo.put("id", data.get(i).id)
                            jsonObjectTareo.put("user", data.get(i).user)
                            jsonObjectTareo.put("costcenter", data.get(i).costcenter)
                            jsonObjectTareo.put("activity", data.get(i).activity)
                            jsonObjectTareo.put("job", data.get(i).job)
                            jsonObjectTareo.put("advance", data.get(i).advance)
                            jsonObjectTareo.put("timeI", data.get(i).timeI)
                            jsonObjectTareo.put("timeF", data.get(i).timeF)
                            jsonObjectTareo.put("timeE", data.get(i).timeE)
                            jsonObjectTareo.put("dni", data.get(i).dni)
                            jsonObjectTareo.put("dia", data.get(i).dia)
                            jsonObjectTareo.put("hora" , data.get(i).hora)
                            jsonObjectTareo.put("estado", data.get(i).estado)
                            jsonObjectTareo.put("totales", data.get(i).totales)
                        }catch (e: JSONException){
                            e.printStackTrace()
                        }
                        jsonArray.put(jsonObjectTareo)
                    }
                    val json = JSONObject()
                    try {
                        json.put("Tareo", jsonArray)
                    }catch (e: JSONException){
                        e.printStackTrace()
                    }
                    val jsonStr: String = json.toString()
                    CoroutineScope(Dispatchers.IO).launch {
                        sendData(jsonStr)

                    }
                }
            }


    fun initView(){
        cantidad = findViewById(R.id.cantidad)

        val cantidadR = crud.getAllTareo()

        val registros = cantidadR.toString().toInt()

        if(registros > 0){
            cantidad.text = "Tiene $registros registro por subir"
        }else{
            cantidad.text = "No tiene registros por subir"

        }
    }

    fun sendData(json: String){
        val requestQueue = Volley.newRequestQueue(this)
        val url = "http://199.241.218.53:60000/tareo/gTareo.php"
        val solicitud = object: StringRequest(Method.POST, url, Response.Listener<String> {
            response ->
            try {
                Toast.makeText(this, "Registro: $response", Toast.LENGTH_SHORT).show()
                val data = crud.getAllPre()

                if(response.equals("ENVIO COMPLETO")){
                    val estado = 4
                    for (i in 0 until data.size){
                        crud.updateTareo(
                            PreModel(
                                data[i].id.toString().toInt(),
                                data[i].user.toString(),
                                data[i].costcenter.toString(),
                                data[i].activity.toString(),
                                data[i].job.toString(),
                                data[i].advance.toString(),
                                data[i].timeI.toString(),
                                data[i].timeF.toString(),
                                data[i].timeE.toString().toFloat(),
                                data[i].dni.toString(),
                                data[i].dia.toString(),
                                data[i].hora.toString(),
                                estado,
                                data[i].nombre.toString(),
                                data[i].totales.toString().toFloat()
                            )
                        )
                    }
                    val intent = Intent(this, Confirmation_Send::class.java)
                    startActivity(intent)
                    finish()
                }

            }catch (e: JSONException){
                Toast.makeText(applicationContext, "response,"+response.toString()+"", Toast.LENGTH_LONG).show()
                e.printStackTrace()
            }

        }, Response.ErrorListener {

            Toast.makeText(applicationContext, "DEBE DE CONECTARSE A INTERNET", Toast.LENGTH_SHORT).show()

        })

        {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params.put("json", json)
                return params
            }
        }
        requestQueue.add(solicitud)
                }

            }
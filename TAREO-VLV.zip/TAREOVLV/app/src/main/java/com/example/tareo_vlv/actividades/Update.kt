package com.example.tareo_vlv.actividades

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.tareo_vlv.R
import com.example.tareo_vlv.crud.TareoCRUD
import com.example.tareo_vlv.database.ActiviyCRUD
import com.example.tareo_vlv.database.LaborCRUD
import com.example.tareo_vlv.database.TrabajadorCRUD
import com.example.tareo_vlv.model.PreModel
import com.example.tareo_vlv.model.TrabajadorModel
import com.google.android.material.floatingactionbutton.FloatingActionButton

class Update : AppCompatActivity() {

    private lateinit var id: EditText
    private lateinit var dni: EditText
    private lateinit var labor: Spinner
    private lateinit var tvCcostos: TextView
    private lateinit var tvAct: TextView
    private lateinit var avance: EditText
    private lateinit var horaI: EditText
    private lateinit var horaF: EditText
    private lateinit var horaE: CheckBox
    private lateinit var fButton: FloatingActionButton
    private lateinit var btnActualizar: Button
    private lateinit var rendimiento: TextView
    private lateinit var cantidad: TextView
    private lateinit var tcrud: TrabajadorCRUD
    private lateinit var acrud: ActiviyCRUD
    private var crud: TareoCRUD? = null
    private var lcrud: LaborCRUD? = null

    var c = 0
    var rendimiento_act = ""
    var comedores = 0.0f
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        //ESTE CODIGO OMITE EL MODO OSCURO
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //ESTE CODIGO MANTIENE LA PANTALLA ENCENDIDA MIENTRAS ESTE ABIERTA LA APLICACION
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_update)

        val index = intent.getStringExtra("idPre")

        crud = TareoCRUD(this)
        lcrud = LaborCRUD(this)
        tcrud = TrabajadorCRUD(this)
        acrud = ActiviyCRUD(this)

        initView()

        getTareos(index.toString())

        val listareo =crud?.getTareo(index)
        val id = listareo?.id.toString().toInt()
        val user = listareo?.user.toString()
        val ccenter = listareo?.costcenter.toString()
        val activity = listareo?.activity.toString()
        updateJob(index.toString(), activity, ccenter)
        val estado: Int = listareo?.estado.toString().toInt()
        val dia = listareo?.dia.toString()
        val hora = listareo?.hora.toString()
        val totales = listareo?.totales.toString()
        val comedor = listareo?.timeE.toString()

        val rendimiento = acrud.selectActivityT(activity, ccenter)


        rendimiento_act += rendimiento.rendimiento.toString()
        //Datos que cambian

        tvCcostos.text = "Centro de Costos: " + ccenter
        tvAct.text = "Fase: " + activity
        val estadoI: Int = estado + 1
        if (estado < 3){

        btnActualizar.setOnClickListener{

                updateTareo(id, user, ccenter, activity, dia, hora, estadoI, totales.toFloat(), comedor.toFloat())

        }

        }else{
            btnActualizar.isEnabled = false
        }

        fButton.setOnClickListener{
            startActivity(Intent(this,UpdateTareo::class.java))
            finish()
        }

    }

    private fun initView(){

        id = findViewById(R.id.etId)
        dni = findViewById(R.id.etDNI)
        avance = findViewById(R.id.etAVANCE)
        btnActualizar = findViewById(R.id.btnActualizar)
        fButton = findViewById(R.id.fButton)
        horaI = findViewById(R.id.etHORAS)
        horaF = findViewById(R.id.etHORASF)
        horaE = findViewById(R.id.etHORASE)
        tvCcostos = findViewById(R.id.tvCcostos)
        tvAct = findViewById(R.id.tvAct)
        labor = findViewById(R.id.etLABOR)
        rendimiento = findViewById(R.id.rendimiento)
        cantidad = findViewById(R.id.cantidad)

    }

    private fun updateTareo(id: Int, user: String, costcenter: String, activity: String,
                            dia: String, hora: String, estado: Int, totales: Float, comedor:Float) {

            val dni = dni.text.toString()
            val avance = avance.text.toString()
            val horaI = horaI.text.toString()
            val horaF = horaF.text.toString()
            val job = labor.selectedItem.toString()
                crud?.updateTareo(PreModel(

                    id = id,
                    user = user,
                    costcenter = costcenter,
                    activity = activity,
                    job = job,
                    advance = avance,
                    timeI = horaI,
                    timeF = horaF,
                    timeE = comedores,
                    dni = dni,
                    dia = dia,
                    hora = hora,
                    estado = estado,
                    nombre = actualizarDNI(dni),
                    totales = totales
                ))

        startActivity(Intent(this, UpdateTareo::class.java))
        finish()
    }

    private fun getTareos(index: String){
        val listareo =crud?.getTareo(index)
        id.setText(listareo!!.id.toString(), TextView.BufferType.EDITABLE)
        dni.setText(listareo.dni, TextView.BufferType.EDITABLE)
        avance.setText(listareo.advance.toString(), TextView.BufferType.EDITABLE)
        horaI.setText(listareo.timeI, TextView.BufferType.EDITABLE)
        horaF.setText(listareo.timeF, TextView.BufferType.EDITABLE)
    }

    private fun updateJob(index: String, actividad: String, ccostos: String) {
        val listareo = crud?.getTareo(index)
        val labores = lcrud?.selectLabor(actividad, ccostos)
        if (labores != null) {
            val listaLabor = arrayListOf<String>()

            for (i in 0 until labores.size) {

                if (listareo != null) {

                    if (labores[i].idlabor.toString() != listareo.job.toString().substring(0, 6)) {

                        c += 1

                    } else {

                        break

                    }
                }
            }

            for (i in 0 until labores.size) {

                listaLabor.add(labores[i].idlabor.toString() + " - " + labores[i].descripcion.toString())

            }

            val adapterLab = ArrayAdapter(this, android.R.layout.simple_spinner_item, listaLabor)
            labor.adapter = adapterLab
            labor.setSelection(c)

            labor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                    val seleccionLab = labor.selectedItem.toString()
                    val codLab = seleccionLab.substring(0,6)
                    val cantidades = codLab.replace(codLab, labores[p2].cantidad.toString())
                    if(rendimiento_act == "NO"){
                        rendimiento.text = "TRADICIONAL"
                    }else{
                        rendimiento.text = "ESTANDAR"
                    }
                    cantidad.text = cantidades
                }

                override fun onNothingSelected(p0: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }

            }
        }

    }

    private fun actualizarDNI(dniu: String): String{
        var newName = ""
        val resultado = getTrabajador(dniu)
        if(resultado){

            val personalR: TrabajadorModel? = tcrud.selectPersonal(dniu)

            val nombren = personalR?.trabajador.toString()

            newName += if(nombren == "null"){
                "Usuario no registrado o valide DNI"
            }else{

                personalR?.trabajador.toString()

            }
        }
        return newName
    }

    private fun getTrabajador(dni: String):Boolean{

        val personalR: TrabajadorModel? = tcrud.selectPersonal(dni)
        return personalR?.equals(null) != true

    }
}
package com.example.tareo_vlv.actividades

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tareo_vlv.R
import com.example.tareo_vlv.crud.TareoCRUD
import com.example.tareo_vlv.model.PreModel
import com.example.tareo_vlv.recyclerView.AdaptadorCustom
import com.example.tareo_vlv.recyclerView.ClickListener
import com.example.tareo_vlv.recyclerView.LongClickListener
import com.google.android.material.floatingactionbutton.FloatingActionButton

class UpdateTareo : AppCompatActivity() {

    private lateinit var listTareo: RecyclerView
    private lateinit var adaptador: AdaptadorCustom
    private lateinit var layoutManager: RecyclerView.LayoutManager
    private lateinit var fButton: FloatingActionButton

    var listareo: ArrayList<PreModel>? = null
    private var temtareo: ArrayList<PreModel>? = null

    private var crud: TareoCRUD? = null

    private var toolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        //ESTE CODIGO OMITE EL MODO OSCURO EN LA APLICACION
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //ESTE CODIGO MANTIENE LA PANTALLA ENCENDIDA MIENTRAS ESTE ABIERTA LA APLICACION
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_update_tareo)

        initToolbar()
        listTareo = findViewById(R.id.listTareo)
        fButton = findViewById(R.id.fButton)
        listTareo.setHasFixedSize(true)
        layoutManager = LinearLayoutManager(this)
        listTareo.layoutManager = layoutManager

        crud = TareoCRUD(this)

        listareo = crud?.getAllPre()
        temtareo?.addAll(listareo!!)

        fButton.setOnClickListener {

            startActivity(Intent(this, PreRegister::class.java))

        }

        adaptador = AdaptadorCustom(listareo!!, object: ClickListener {
            override fun onClick(view: View, index: Int) {
                val intent = Intent(applicationContext, Update::class.java)
                intent.putExtra("idPre", listareo!![index].id.toString())
                startActivity(intent)
                finish()
            }

        },
            object : LongClickListener {

            override fun longClick(view: View, index: Int) {
                crud?.dropTareo(listareo!![index].id.toString().toInt())
                val intent = Intent(applicationContext, UpdateTareo::class.java)
                startActivity(intent)
            }
        })

        listTareo.adapter = adaptador

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_search, menu)

        val item = menu?.findItem(R.id.searchTareo)
        val busca = item?.actionView as SearchView
        busca.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adaptador.filter.filter(newText)
                return true
            }

        })
        item.setOnActionExpandListener(object : MenuItem.OnActionExpandListener{
            override fun onMenuItemActionExpand(p0: MenuItem?): Boolean {

                return true
            }

            override fun onMenuItemActionCollapse(p0: MenuItem?): Boolean {
                adaptador.filter.filter("")
                return true
            }

        })
        return super.onCreateOptionsMenu(menu)
    }

    private fun initToolbar(){
        toolbar = findViewById(R.id.sToolbar)
        toolbar?.setLogo(R.mipmap.ic_principal_icon_fondo_round)
        supportActionBar?.setDisplayUseLogoEnabled(false)
        setSupportActionBar(toolbar)
    }
}
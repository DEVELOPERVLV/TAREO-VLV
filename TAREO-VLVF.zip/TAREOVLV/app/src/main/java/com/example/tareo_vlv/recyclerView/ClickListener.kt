package com.example.tareo_vlv.recyclerView

import android.view.View

interface ClickListener {
    fun onClick(view: View, index: Int)
}
package com.example.tareo_vlv.recyclerView

import android.view.View

interface LongClickListener {

    fun longClick(view: View, index: Int)
}
package com.example.tareo_vlv.actividades

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.tareo_vlv.Confirmation_Send
import com.example.tareo_vlv.Error_Send
import com.example.tareo_vlv.R
import com.example.tareo_vlv.database.*
import com.example.tareo_vlv.model.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import kotlin.system.measureTimeMillis


class SyncSuccess : AppCompatActivity() {


    private lateinit var tcrud: TrabajadorCRUD
    private lateinit var costcrud: CcenterCRUD
    private lateinit var acrud: ActiviyCRUD
    private lateinit var lcrud: LaborCRUD
    private lateinit var tacrud: TareadorCRUD
    private lateinit var culcrud: CultivoCRUD

    private var c = 0
    private var a = 0
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        //ESTE CODIGO OMITE EL MODO OSCURO EN EL APP
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //ESTE CODIGO MANTIENE LA PANTALLA ENCENDIDA MIENTRAS ESTE ABIERTA LA APLICACION
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_sync_success)

        tcrud = TrabajadorCRUD(this)
        tacrud = TareadorCRUD(this)
        culcrud = CultivoCRUD(this)
        costcrud = CcenterCRUD(this)
        acrud = ActiviyCRUD(this)
        lcrud = LaborCRUD(this)

        updateData()

    }


    private fun updateData(){
        val btnUpd = findViewById<Button>(R.id.btnUpd)

                btnUpd.setOnClickListener {
                    a+=1
                    val sharedPref = getSharedPreferences("password", Context.MODE_PRIVATE)
                    val savedString = sharedPref.getString("STRING_KEY", null)
                    val userRegistra = savedString.toString()

                    CoroutineScope(Dispatchers.IO).launch {
                        tcrud.deleteTrabajador()
                        culcrud.delelteCultivo()
                        costcrud.deleteCcenter()
                        lcrud.deleteLabor()
                        acrud.deleteActivity()
                        measureTimeMillis {
                            val job1 = launch {
                                delay(500L)
                                cultivoHTTP(userRegistra)
                            }
                            val job2 = launch {
                                delay(400L)
                                trabajadorHTTP()
                            }

                            joinAll(job1, job2)

                        }
                    }
                    if(a==1){
                        btnUpd.isEnabled = false
                    }
                }
            }

    private fun trabajadorHTTP(){
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(
            Request.Method.GET, "http://199.241.218.53:60000/tareo/personal_tareo.php", { response ->
                try {
                    val jsonArray = JSONArray(response)
                    val cantidad = jsonArray.length()
                    //progressBarA(cantidad)
                    //c=0
                    for(i in 0 until jsonArray.length()){
                        val jsonObject = jsonArray.getJSONObject(i)
                        val idcodigogeneral = jsonObject.getString("IDCODIGOGENERAL")
                        val trabajador = jsonObject.getString("TRABAJADOR")

                        tcrud.insertPersonal(TrabajadorModel(idcodigogeneral, trabajador))

                        c+=1
                        if(c == cantidad) {

                            redirection()

                        }

                    }

                }catch (e:Exception){

                }
            },

            { error ->

                error.message?.let { Log.d("HTTP_REQUEST", it) }

            })

        queue.add(stringRequest)
        queue.cache.clear()
    }

    private fun cultivoHTTP(dni: String){
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(

            Request.Method.GET, "http://199.241.218.53:60000/tareoCultivo/cultivo_dni.php?funcion=obtenerCultivos&dni=$dni", { response ->
                try {
                    val jsonArray = JSONArray(response)
                    for(i in 0 until jsonArray.length()){
                        val jsonObject = jsonArray.getJSONObject(i)
                        val idcultivo = jsonObject.getString("idCultivo")
                        val dni = jsonObject.getString("dni")
                        val descripcion = jsonObject.getString("descripcion")

                        culcrud.insertCultivo(CultivoModel( idcultivo, dni, descripcion))
                        costosHTTP(idcultivo)
                        println("descripcion::"+descripcion)
                    }
                }catch (e:Exception){

                }
            },
            {
                a+=0

                val intent = Intent(this, Error_Send::class.java)
                startActivity(intent)

            })
        queue.add(stringRequest)
        queue.cache.clear()
    }

    private fun costosHTTP(cultivo: String){
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(

                Request.Method.GET, "http://199.241.218.53:60000/tareoCultivo/costCenter_to_tareo.php?funcion=obtenerCCostos&cultivo=$cultivo", { response ->
                    try {
                        val jsonArray = JSONArray(response)
                        for(i in 0 until jsonArray.length()){
                            val jsonObject = jsonArray.getJSONObject(i)
                            val idcultivo = jsonObject.getString("idCultivo")
                            val idconsumidor = jsonObject.getString("IDCONSUMIDOR")

                            costcrud.insetCCenter(CCenterModel(idcultivo, idconsumidor))

                            activityHTTP(idconsumidor)

                        }

                    }catch (e:Exception){

                    }
                },

            {


            })
        queue.add(stringRequest)
        queue.cache.clear()
    }


    private fun activityHTTP(ccostos: String){
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(
            Request.Method.GET,
            "http://199.241.218.53:60000/tareo/actividad_ccostos.php?funcion=obtenerActividad&ccostos=$ccostos",
            { response ->
                try {
                    val jsonArray = JSONArray(response)
                    for (i in 0 until jsonArray.length()) {
                        val jsonObject = jsonArray.getJSONObject(i)
                        val idactividad = jsonObject.getString("IDACTIVIDAD")
                        val descripcion = jsonObject.getString("DESCRIPCION")
                        val rendimiento = jsonObject.getString("POR_RENDIMIENTO")
                        val idconsumidor = jsonObject.getString("IDCONSUMIDOR")

                        acrud.insertActivity(
                            ActivityModel(idactividad, descripcion, rendimiento, idconsumidor)
                        )


                        laboresHTTP(idactividad.trim(), idconsumidor.trim())


                    }

                }catch (e:Exception){

                }
            }, {error ->

                error.message?.let { Log.d("HTTP_REQUEST", it) }

            })
        queue.add(stringRequest)
        queue.cache.clear()
    }

    private fun laboresHTTP(idactividad: String, idconsumidor: String){
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(
                Request.Method.GET,

            "http://199.241.218.53:60000/tareoTI/activity_labor.php?funcion=obtenerLabor&actividad=$idactividad&idconsumidor=$idconsumidor", {
                    response ->
                try {
                    val jsonArray = JSONArray(response)
                    for(i in 0 until jsonArray.length()){
                        val jsonObject = jsonArray.getJSONObject(i)
                        val actividad = jsonObject.getString("idactividad")
                        val idlabor = jsonObject.getString("idlabor")
                        val descripcion = jsonObject.getString("descripcion")
                        val cantidad = jsonObject.getString("cantidad")
                        val consumidor = jsonObject.getString("IDCONSUMIDOR")

                        lcrud.insertLabor(LaborModel(actividad, idlabor , descripcion, cantidad, consumidor))

                    }
                }catch (e: Exception){

                }

                },

            { error ->

                error.message?.let { Log.d("HTTP_REQUEST", it) }

            })
        queue.add(stringRequest)
        queue.cache.clear()
    }

    private fun redirection(){

            val intent = Intent(this, Confirmation_Send::class.java)
            startActivity(intent)


    }

    }
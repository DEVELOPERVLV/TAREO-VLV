package com.example.tareo_vlv.actividades

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteException
import android.os.Bundle
import android.text.TextWatcher
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.Toolbar
import androidx.core.view.isEmpty
import com.example.tareo_vlv.R
import com.example.tareo_vlv.crud.TareoCRUD
import com.example.tareo_vlv.database.*
import com.example.tareo_vlv.model.PreModel
import com.example.tareo_vlv.model.TrabajadorModel
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult
import java.text.SimpleDateFormat
import java.util.*


class PreRegister : AppCompatActivity() {

    private lateinit var cultivo : Spinner
    private lateinit var costcenter: Spinner
    private lateinit var activity: Spinner
    private lateinit var job: Spinner
    private lateinit var dni: EditText
    private lateinit var advance: EditText
    private lateinit var timeI : EditText
    private lateinit var timeF : EditText
    private lateinit var timeE : CheckBox
    private lateinit var btnPre: Button
    private lateinit var btnScanner: Button
    private lateinit var crud: TareoCRUD

    private lateinit var culcrud: CultivoCRUD
    private lateinit var costcrud: CcenterCRUD
    private lateinit var acrud: ActiviyCRUD
    private lateinit var lcrud: LaborCRUD
    private lateinit var dbhelper: SQLiteOpenHelper
    private lateinit var tcrud: TrabajadorCRUD
    private lateinit var tarcrud: TareadorCRUD
    private lateinit var rendimiento: TextView
    private lateinit var cantidad: TextView

    var toolbar:Toolbar? = null

    var comedor = 0.0f

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        //ESTE CODIGO OMITE EL MODO OSCURO EN LA APLICACION
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //ESTE CODIGO MANTIENE LA PANTALLA ENCENDIDA MIENTRAS ESTE ABIERTA LA APLICACION
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_pre_register)
        supportActionBar?.hide()

        culcrud = CultivoCRUD(this)
        costcrud = CcenterCRUD(this)
        acrud = ActiviyCRUD(this)
        lcrud = LaborCRUD(this)
        tcrud = TrabajadorCRUD(this)
        tarcrud = TareadorCRUD(this)

        initView()
        initSpinner(this)
        initToolbar()
        blockSpinner()

        crud = TareoCRUD(this)
        dbhelper = SQLiteOpenHelper(this)

        btnPre.setOnClickListener {
            if(costcenter.isEmpty()){
                Toast.makeText(this, "Descargue/Actualice datos", Toast.LENGTH_SHORT).show()
            }else{
                addPre()
            }

        }

        btnScanner.setOnClickListener { initScanner() }

    }

    fun initToolbar(){

        toolbar = findViewById(R.id.my_toolbar)
        toolbar?.setLogo(R.mipmap.ic_principal_icon_fondo_round)
        supportActionBar?.setDisplayUseLogoEnabled(false)
        setSupportActionBar(toolbar)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_principal, menu)

        return super.onCreateOptionsMenu(menu)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean{

        when(item.itemId){

            R.id.icon_register -> {
                val intent = Intent(this, Register()::class.java)
                startActivity(intent)
                return true

            }
            R.id.icon_sync -> {
                val intent = Intent(this, SyncSuccess()::class.java)
                startActivity(intent)
                return true

            }
            R.id.icon_view -> {
                val intent = Intent(this, UpdateTareo()::class.java)
                startActivity(intent)
                return true

            }

            R.id.icon_logout -> {
                logout()
                return true
            }

            else -> {return super.onOptionsItemSelected(item)}

        }

    }



    private fun initView(){
        cultivo = findViewById(R.id.cultivo)
        costcenter = findViewById(R.id.costProd)
        activity = findViewById(R.id.activity)
        timeI = findViewById(R.id.timeI)
        timeF = findViewById(R.id.timeF)
        timeE = findViewById(R.id.timeE)
        job = findViewById(R.id.job)
        dni = findViewById(R.id.dni)
        advance = findViewById(R.id.advance)
        btnPre = findViewById(R.id.btnPre)
        btnScanner = findViewById(R.id.btnScanner)
        rendimiento = findViewById(R.id.rendimiento)
        cantidad = findViewById(R.id.cantidad)

    }

    private fun initSpinner(context: Context) {

        arrayListOf("No se encuentra ningún valor")
        val sharedPref = getSharedPreferences("password", Context.MODE_PRIVATE)
        val savedString = sharedPref.getString("STRING_KEY", null)
        val userRegistra = savedString.toString()

        val cultivos = culcrud.selectCultivo(userRegistra)
        val listCultivo = arrayListOf<String>()
        for(i in 0 until cultivos.size){

            listCultivo.add(cultivos[i].descripcion.toString())

        }

        val adaptadorcul = ArrayAdapter(context, android.R.layout.simple_spinner_item, listCultivo)
        cultivo.adapter = adaptadorcul

        cultivo.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

                val selection = cultivos[p2].idCultivo.toString()

                val campana = costcrud.selectCCenter(selection)
                val lista = arrayListOf<String>()
                for (i in 0 until campana.size) {

                    lista.add(campana[i].idconsumidor.toString())

                }

                val adaptador =
                    ArrayAdapter(context, android.R.layout.simple_spinner_item, lista)
                costcenter.adapter = adaptador

                costcenter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        val selection = campana[position].idconsumidor.toString()
                        val actividad = acrud.selectActivity(selection)

                        Log.d("Actividades ::", actividad.toString())

                        val listaCampania = arrayListOf<String>()

                        for (i in 0 until actividad.size) {

                            listaCampania.add(actividad[i].idactividad.toString() + " - " + actividad[i].descripcion.toString())

                        }

                        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, listaCampania)
                        activity.adapter = adapter

                        activity.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                                val seleccion = activity.selectedItem.toString()
                                val codAct = seleccion.substring(0,3)
                                val rendimiento_act = actividad[p2].rendimiento.toString()

                                Log.d("Rendimiento ::", rendimiento_act)
                                Log.d("Actividad ::", codAct)
                                Log.d("CCOSTOS ::", selection)
                                val labor = lcrud.selectLabor(codAct, selection)

                                val listaLabor = arrayListOf<String>()

                                for (i in 0 until labor.size) {

                                    listaLabor.add(labor[i].idlabor.toString() + " - " + labor[i].descripcion.toString())

                                }

                                val adapterLab = ArrayAdapter( context, android.R.layout.simple_spinner_item, listaLabor)
                                job.adapter = adapterLab

                                job.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                                    override fun onItemSelected( p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                                        val seleccionLab = job.selectedItem.toString()
                                        val codLab = seleccionLab.substring(0,6)
                                        val cantidades = codLab.replace(codLab, labor[p2].cantidad.toString())


                                        if(rendimiento_act == "NO"){
                                            rendimiento.text = "TRADICIONAL"
                                        }else{
                                            rendimiento.text = "ESTANDAR"
                                        }
                                        cantidad.text = cantidades


                                    }

                                    override fun onNothingSelected(p0: AdapterView<*>?) {
                                        TODO("Not yet implemented")
                                    }

                                }

                            }

                            override fun onNothingSelected(p0: AdapterView<*>?) {
                                TODO("Not yet implemented")
                            }

                        }

                    }

                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        TODO("Not yet implemented")

                    }


                }

            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }

    }

    private fun blockSpinner(){

        val block = findViewById<SwitchMaterial>(R.id.block)
        block?.setOnCheckedChangeListener{ _, isChecked ->
            if(isChecked){
                costcenter.isEnabled = false
                activity.isEnabled = false
                job.isEnabled = false
            }else{
                costcenter.isEnabled = true
                activity.isEnabled = true
                job.isEnabled = true
            }
        }
    }

    private fun initScanner(){
        val integrator = IntentIntegrator(this)
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
        integrator.setTorchEnabled(true)
        integrator.setBeepEnabled(true)
        integrator.initiateScan()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val result: IntentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)

        if(result.contents == null){
          Toast.makeText(this, "Cancelado", Toast.LENGTH_SHORT).show()
          }else{
              dni.setText(result.contents)

              val documento = result.contents
              val personal = getTrabajador(documento)
              if(personal){
                  val personalR: TrabajadorModel? = tcrud.selectPersonal(documento)
                  val nombre = personalR?.trabajador.toString()
                  if(nombre != "null")
                  Toast.makeText(this, personalR?.trabajador.toString(), Toast.LENGTH_SHORT).show()
              }else{
                  Toast.makeText(this, documento, Toast.LENGTH_SHORT).show()
              }

          }
    }

    private fun addPre(){
        val sharedPref = getSharedPreferences("password",Context.MODE_PRIVATE)
        val savedString = sharedPref.getString("STRING_KEY", null)
        val userRegistra = savedString.toString()
        val costcenter = costcenter.selectedItem.toString()
        val dni = dni.text.toString()
        val activ = activity.selectedItem.toString()
        val activity = activ.substring(0,3)
        val job = job.selectedItem.toString()
        val labor = job.substring(0,6)
        val advance = advance.text.toString()
        val timeI = timeI.text.toString()
        val timeF = timeF.text.toString()
        if(timeE.isChecked){
            comedor+=0.45f
        }else{
            comedor+=0.0f
        }
        val timeE = timeE.text.toString()
        val cal: Calendar = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd")
        val strDate: String = sdf.format(cal.time)
        val shf = SimpleDateFormat("HH:mm:ss")
        val strHour: String = shf.format(cal.time)
        val estado = 1

        if(dni.isEmpty() || timeI.isEmpty() || timeF.isEmpty()){

            Toast.makeText(this, "No debe de tener DNI, Fecha Inicio y Fin Vacío", Toast.LENGTH_SHORT).show()

        }else{

            try{
                    val trabajador = getTrabajador(dni)
                        if(trabajador){
                            val personalR: TrabajadorModel? = tcrud.selectPersonal(dni)
                            val nombre = personalR?.trabajador.toString()
                            Log.d("error ::", nombre)
                            if(timeF.trim().toFloat() < timeI.trim().toFloat()){
                                Toast.makeText(this, "La hora de inicio no puede ser menor a la hora de fin, registre en formato 24 horas", Toast.LENGTH_LONG).show()
                                clearEditText()

                            }else {
                                val laboradas = (timeF.toFloat() - timeI.toFloat())
                                val guardarhoras = "%.0f".format(laboradas).toFloat()

                                if(nombre == "null"){

                                    Toast.makeText(this, "Pre registro agregado trabajador " + dni + " FALTA REGISTRAR", Toast.LENGTH_SHORT).show()
                                    val status = crud.insertPre(PreModel(
                                        id = null,user = userRegistra.trim(), costcenter = costcenter, activity = activity,
                                        job = job, advance = advance.trim(), timeI = timeI.trim(), timeF = timeF.trim(), timeE = comedor,
                                        dni = dni.trim(), dia = strDate, hora = strHour, estado = estado, nombre = "Usuario no registrado o valide DNI", totales = guardarhoras))

                                    if(status > -1){

                                        clearEditText()

                                    }else{
                                        Toast.makeText(this, "No se ha registrado", Toast.LENGTH_SHORT).show()
                                    }

                                }else{

                                    Toast.makeText(this, "Pre registro agregado trabajador: " + nombre, Toast.LENGTH_SHORT).show()

                                    val status = crud.insertPre(PreModel(
                                        id = null,user = userRegistra.trim(), costcenter = costcenter, activity = activity,
                                        job = job, advance = advance.trim(), timeI = timeI.trim(), timeF = timeF.trim(), timeE = comedor,
                                        dni = dni.trim(), dia = strDate, hora = strHour, estado = estado, nombre = nombre, totales = guardarhoras))
                                    if(status > -1){

                                        clearEditText()

                                    }else{
                                        Toast.makeText(this, "No se ha registrado", Toast.LENGTH_SHORT).show()
                                    }

                                }
                            }


                        }else{
                            Toast.makeText(this, "Trabajador no encontrado en Nisira", Toast.LENGTH_SHORT).show()
                        }

                }catch (e: SQLiteException){
                e.printStackTrace()

            }

        }

    }

    fun clearEditText(){
        dni.setText("")
        advance.setText("")
        timeE.setText("")
    }

    fun getTrabajador(dni: String):Boolean{

        val personalR: TrabajadorModel? = tcrud.selectPersonal(dni)
        return personalR?.equals(null) != true

    }

    fun logout(){
        val sharedPref = getSharedPreferences("password",Context.MODE_PRIVATE)
        val savedString = sharedPref.edit().remove("STRING_KEY").commit()
        Log.d("Preferences::",savedString.toString())
        if (savedString){
            val intent = Intent(this, MainActivity()::class.java)
            startActivity(intent)
            finish()
        }
    }

    fun getComida(){

    }

}
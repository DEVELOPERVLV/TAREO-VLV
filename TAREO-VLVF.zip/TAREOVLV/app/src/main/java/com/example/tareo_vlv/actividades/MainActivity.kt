package com.example.tareo_vlv.actividades

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteException
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.tareo_vlv.R
import com.example.tareo_vlv.database.TareadorCRUD
import com.example.tareo_vlv.model.TareadorModel
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    private lateinit var password: TextInputLayout
    private lateinit var ePassword: TextInputEditText
    private lateinit var bLog: Button

    private lateinit var tacrud: TareadorCRUD

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //ESTE CODIGO OMITE EL MODO OSCURO EN LA APLICACION
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //ESTE CODIGO MANTIENE LA PANTALLA ENCENDIDA MIENTRAS ESTE ABIERTA LA APLICACION
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_main)
        tacrud = TareadorCRUD(this)

        //var docu:String = "72768326"

        val sharedPref = getSharedPreferences("password",Context.MODE_PRIVATE)
        val savedString = sharedPref.getString("STRING_KEY", null)
        //println("Password ::"+savedString)

        initView()

         if(savedString == null){

            bLog.setOnClickListener { login() }
         }else{
             if(savedString.isNotEmpty()){
                 val intent = Intent(this, PreRegister::class.java)
                 startActivity(intent)
                 finish()
             }
         }

    }

    private fun initView(){
        password = findViewById(R.id.password)
        ePassword = findViewById(R.id.contrasenia)
        bLog = findViewById(R.id.bLog)
    }

    private fun saveSharedPreferences(password: String){
        val sharedPref = getSharedPreferences("password", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()
        editor.apply{
            putString("STRING_KEY", password)
        }.apply()
    }

    private fun login(){
        val password = ePassword.text.toString().trim()
        try {
            val tareador = getTarear(password)

            if(tareador){
                val dni = tacrud.getTareador(password)
                val dniL = dni?.DNI.toString().trim()
                if (password == dniL) {


                    saveSharedPreferences(dniL)
                    val intent = Intent(this, PreRegister::class.java)
                    startActivity(intent)
                    finish()
                } else {

                    Toast.makeText(this,"Contraseña incorrecta o no existe el usuario", Toast.LENGTH_SHORT).show()

                }
            }else{

                Toast.makeText(this,"Solicite Igreso de Usuario", Toast.LENGTH_SHORT).show()

            }
        }catch (e: SQLiteException){

            e.printStackTrace()

        }

    }

    fun getTarear(password: String):Boolean{

        val personalR: TareadorModel? = tacrud.getTareador(password)
        return personalR?.equals(null) != true

    }

}